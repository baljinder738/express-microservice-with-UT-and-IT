//TODO -- add basic user validation
import {Request, Response, NextFunction} from "express"
import data from "../config/data";
import ApiError from "../utils/errorHandling/apiErrors";

const userAuth = (req:Request, res:Response, next:NextFunction) => {
   try {const token = req.header("Authorization")!.replace("Bearer", "");
    const id = parseInt(token);
    const user = data.findIndex(user => user.id === id);
    if (!user) throw new Error()
    next();
 } catch (err) {
    return next(ApiError.notAuthenticated("please Authenticate ..."))
 }
}

export default userAuth;