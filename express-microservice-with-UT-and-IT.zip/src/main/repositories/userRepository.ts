import data from "../config/data";
import { User } from "../models/user";


export interface UserRepository {
  getAllUserData(): User[],
  deleteUserById(id: number): User,
  getUserById(id: number): User,
  createUser(user: User) : User,
  updateUser(id: number, user: User) : User
}

export default class UserRepositoryImpl implements UserRepository {
  getAllUserData(): User[] {
    return data;
  }
  deleteUserById(id: number): User {
    const userIndex = data.findIndex((user) => user.id === id);
    const deletedUser = data[userIndex]
    data.splice(userIndex, 1)
    return deletedUser
  }
  getUserById(id: number): User {
    const userById = data.find((user) => user.id === id)!
    return userById;
  }
  createUser(user: User): User {
    data.push(user);
    return user
  }
  updateUser(id: number, user: User): User {
       const userIndex = data.findIndex((user) => user.id === id);
       const updatedUser = {
         ...data[userIndex],
         ...user
       };
       data.splice(userIndex, 1, updatedUser)
       return updatedUser;
  }
}
// const userRepo = new UserRepositoryImpl();
// export default userRepo;
