"use strict";

import { NextFunction, Request, Response } from "express";
import UserServiceImpl from "../services/userService";
import ApiError from "../utils/errorHandling/apiErrors";


//TODO -- convert it into the class

 export const getUsers = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const users = await new UserServiceImpl().getAllUserData();
      res.status(200).json(users);
    } catch (err) {
      next(ApiError.notFound("users not found"))
    }
  }

 export const getUserById = (req: Request, res: Response, next: NextFunction) => {
    try {
      const id: number = parseInt(req.params.id)
      const user = new UserServiceImpl().getUserById(id);
      res.json(user)
    } catch (err) {
      next(ApiError.notFound("users not found"))
    }
  }

 export const createUser = (req: Request, res: Response, next:NextFunction) => {
  try {
      const user = req.body.user
      if (!user) throw new Error();
      const createdUser = new UserServiceImpl().createUser(user);
      res.json(createdUser);
    } catch (err) {
      next(ApiError.badRequest("bad request"))
    }
  }

 export const updateUser = (req: Request, res: Response, next: NextFunction) => {
    try {
      const id: number = parseInt(req.params.id)
      const updateData = req.body.user
      if (!id || updateData) throw new Error("id or user is missing")
      const user = new UserServiceImpl().updateUser(id, updateData);
      res.json(user);
    } catch (err) {
      next(ApiError.badRequest("bad request, " + err))
    }
  }

 export const deleteUserById = (req: Request, res: Response, next: NextFunction) => {
    try {
      const id: number = parseInt(req.params.id)
      if (!id) throw new Error("id is missing")
      const user = new UserServiceImpl().deleteUserById(id);
      res.json(user);
    } catch (err) {
      next(ApiError.badRequest("bad request, " + err))
    }
  }


