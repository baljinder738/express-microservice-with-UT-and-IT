/* eslint-disable linebreak-style */
const data = [
  {id:1, name: "amit", age: 21, gender: "Male" },
  {id:2, name: "ankit", age: 22, gender: "Male" },
  {id:3, name: "anil", age: 21, gender: "Male" },
  {id:4, name: "amit", age: 25, gender: "Male" },
  {id:5, name: "anil", age: 20, gender: "Female" },
  {id:6, name: "amey", age: 21, gender: "Female" },
  {id:7, name: "amiy", age: 29, gender: "Male" },
  {id:8, name: "ashish", age: 29, gender: "Male" },
  {id:9, name: "anand", age: 53, gender: "Male" },
  {id:10, name: "swapnil", age: 20, gender: "Female" },
  {id:11, name: "baljinder", age: 19, gender: "M" },
  {id:12, name: "lalit", age: 33, gender: "Male" },
];

export default data;
