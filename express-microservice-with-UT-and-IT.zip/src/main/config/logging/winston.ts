// const { NodeTracerProvider } = require('@opentelemetry/sdk-trace-node');
// const { WinstonInstrumentation } = require('@opentelemetry/instrumentation-winston');
// const { registerInstrumentations } = require('@opentelemetry/instrumentation');

// const provider = new NodeTracerProvider();
// provider.register();

// registerInstrumentations({
//   instrumentations: [
//     new WinstonInstrumentation({
//       // Optional hook to insert additional context to log metadata.
//       // Called after trace context is injected to metadata.
//       logHook: (record, span) => {
//           console.log("redo "+record +" " +span)
//         record['resource.service.name'] = provider.resource.attributes['service.name'];
//       },
//     }),
//     // other instrumentations
//   ],
// });

// const winston = require('winston');
// const logger = winston.createLogger({
//   transports: [new winston.transports.Console()],
// });
// logger.info('foobar');
// // {"message":"foobar","trace_id":"e21c7a95fff34e04f77c7bd518779621","span_id":"b7589a981fde09f4","trace_flags":"01", ...}
// module.exports = logger;


// import { NodeTracerProvider } from '@opentelemetry/sdk-trace-node';
// import { WinstonInstrumentation } from '@opentelemetry/instrumentation-winston';
// import { registerInstrumentations } from '@opentelemetry/instrumentation';
// import winston from 'winston';

// const provider = new NodeTracerProvider();
// provider.register();

// registerInstrumentations({
//   instrumentations: [
//     new WinstonInstrumentation({
//       // Optional hook to insert additional context to log metadata.
//       // Called after trace context is injected to metadata.
//       logHook: (record: any, span) => {
//         record['resource.service.name'] = provider.resource.attributes['service.name'];
//       },
//     }),
//     // other instrumentations
//   ],
// });

// const logger = winston.createLogger({
//   transports: [new winston.transports.Console()],
// });
// export default  logger;

// import * as opentelemetry from '@opentelemetry/api';
// import { Span } from '@opentelemetry/api';
// import { Format, format } from 'logform';
// import { createLogger } from 'winston';

// function tracingFormat(): Format {
//   const tracer = opentelemetry.trace.getTracer('dd');
//   return format(info => {
//     console.log(info)
//     const span: Span | undefined = opentelemetry.trace.getSpan(opentelemetry.context.active());
//     console.log(span)
//     if (span) {
//       const context = span.spanContext();
//       console.log(context.traceId)
//       info['trace.id'] = context.traceId;
//       info['span.id'] = context.spanId;
//     }
//     return info;
//   })();
// }

// const logger = createLogger({
//   format: format.combine(tracingFormat(), format.json())
// });
// export default  logger;



const { NodeTracerProvider } = require('@opentelemetry/sdk-trace-node');
const { WinstonInstrumentation } = require('@opentelemetry/instrumentation-winston');
const { registerInstrumentations } = require('@opentelemetry/instrumentation');

const provider = new NodeTracerProvider();
provider.register();

registerInstrumentations({
  instrumentations: [
    new WinstonInstrumentation({
      // Optional hook to insert additional context to log metadata.
      // Called after trace context is injected to metadata.
      logHook: (record: any, span: any) => {
        record['resource.service.name'] = provider.resource.attributes['service.name'];
      },
    }),
    // other instrumentations
  ],
});

const winston = require('winston');
const logger = winston.createLogger({
  transports: [new winston.transports.Console()],
})
logger.info('foobar');
export default  logger;