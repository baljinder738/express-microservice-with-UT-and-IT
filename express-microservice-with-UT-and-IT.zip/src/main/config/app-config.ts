/* eslint-disable linebreak-style */
// eslint-disable-next-line import/prefer-default-export
// eslint-disable-next-line no-unused-vars
const APP_CONFIG = {
  APP: {
    PORT: process.env.PORT || "3000",
  },
  DB: {
    USERNAME: process.env.DB_USERNAME || "",
    PASSWORD: process.env.DB_PASSWORD || "",
    HOST: process.env.DB_HOST || "",
    DATABASE: process.env.DB_NAME || "",
  },
};

export default APP_CONFIG;
