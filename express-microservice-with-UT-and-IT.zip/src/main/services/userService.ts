"use strict";

import { User } from "../models/user";
import UserRepositoryImpl, { UserRepository } from "../repositories/userRepository";


interface UserService {
  getAllUserData(): User[],
  deleteUserById(id: number): User,
  getUserById(id: number): User,
  createUser(user: User) : User,
  updateUser(id: number, user: User) : User
}

export default class UserServiceImpl implements UserService {
  public repo:UserRepository;
  constructor() {
    this.repo = new UserRepositoryImpl();
  }
  
  getAllUserData(): User[] {
    return this.repo.getAllUserData();
  }
  deleteUserById(id: number): User {
    // TODO - error handling here
    if (id === 30) throw new Error("the user is invalid")
     return this.repo.deleteUserById(id)
  }
  getUserById(id: number): User {
    if (id === 30) throw new Error("the user is invalid")
     return this.repo.getUserById(id)
  }
  createUser(user: User): User {
    return this.repo.createUser(user)
  }
  updateUser(id: number, user: User): User {
    return this.repo.updateUser(id, user)
  }
}

// const userService = new UserServiceImpl();
// export default userService;



