"use strict";

interface Error {
    statusCode: number,
    message: string,
}

class ApiError implements Error {
    statusCode: number;
    message: string;
    constructor(statusCode: number, message: string) {
       this.statusCode = statusCode;
       this.message = message;
    }

    static badRequest = (msg:string) => {
        return new ApiError(400, msg)
    }

    static notFound = (msg: string) => {
        return new ApiError(404, msg)
    }

    static notAuthenticated = (msg: string) => {
        return new ApiError(401, msg)
    }

    static internalServerError = (msg: string) => {
        return new ApiError(500, msg)
    }
    
}

export default ApiError;