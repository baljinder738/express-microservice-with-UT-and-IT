import { NextFunction, Request, Response, ErrorRequestHandler } from "express";
import logger from "../../config/logging/winston";
import ApiError from "./apiErrors";


const apiErrorHandler:ErrorRequestHandler = (error, req:Request, res:Response, next: NextFunction) => {
     if (error instanceof ApiError) {
         res.status(error.statusCode).send(error.message);
         logger.error(error.message)
         return
     }

     // TODO - add logging add documentation..

     res.send(error.statusCode || 500).send("something went wrong");
}

export default apiErrorHandler;