import express, {Application, NextFunction, Request, Response, ErrorRequestHandler } from "express";
import cors from "cors";
import responseTime from "response-time";
import logger from "./config/logging/winston";
import userRoutes from "./routes/userRoutes";
import { countAllRequests } from "./config/logging/monitoring";
import apiErrorHandler from "./utils/errorHandling/apiErrorHandler";

const app:Application = express();

app.use(express.json({ limit: "50mb" }));
app.use(cors());
// app.use(responseTime());
// app.use(countAllRequests());
app.use(userRoutes); // app.use to add middleware in express
app.use(apiErrorHandler)

const port = 3000;

app.listen(port, () => logger.info('server is running at port 3000'));
// eslint-disable-next-line no-use-before-define
// server.on("error", onError);
// server.on("listening", onListening);

/**
 * Normalize a port into a number, string, or false.
 */

// function normalizePort(val: string) {
//   const normalizPort = parseInt(val, 10);

//   if (isNaN(normalizPort)) {
//     // named pipe
//     return val;
//   }

//   if (normalizPort >= 0) {
//     // port number
//     return normalizPort;
//   }

//   return false;
// }

/**
 * Event listener for HTTP server "error" event.
 */

// function onError(error: any) {
//   if (error.syscall !== "listen") {
//     throw error;
//   }

//   const bind = typeof port === "string" ? `Pipe ${port}` : `Port ${port}`;

//   // handle specific listen errors with friendly messages
//   switch (error.code) {
//     case "EACCES":
//       console.error(`${bind} requires elevated privileges`);
//       process.exit(1);
//       break;
//     case "EADDRINUSE":
//       console.error(`${bind} is already in use`);
//       process.exit(1);
//       break;
//     default:
//       throw error;
//   }
// }

/**
 * Event listener for HTTP server "listening" event.
 */

// function onListening() {
//   const addr:any = server.address();
//   const bind = typeof addr === "string" ? `pipe ${addr}` : `port ${addr.port}`;
//   // debug(`Listening on ${bind}`);
// }

export default app;
