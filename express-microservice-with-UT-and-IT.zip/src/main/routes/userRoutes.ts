import express, {Request, Response, Router} from "express";
import { createUser, getUsers, getUserById, updateUser, deleteUserById } from "../controllers/userController";
import userAuth from "../middleware/userAuth";

const userRoutes:Router = express.Router();

userRoutes.get("/users",  getUsers)
userRoutes.post("/user/new",  createUser)
userRoutes.get("/user/:id", userAuth , getUserById)
userRoutes.patch("/user/update/:id", userAuth , updateUser)
userRoutes.delete("/user/delete/:id", userAuth , deleteUserById)

export default userRoutes;
