"use strict";

import { createUser, getUsers, getUserById, updateUser, deleteUserById } from "../../../main/controllers/userController";
import userAuth from "../../../main/middleware/userAuth";
const getSpy = jest.fn();
const useSpy = jest.fn();
const postSpy = jest.fn();
const patchSpy = jest.fn();
const deleteSpy = jest.fn();

jest.doMock("express", () => ({
  Router() {
    return {
      get: getSpy,
      use: useSpy,
      post: postSpy,
      patch: patchSpy,
      delete: deleteSpy,
    };
  },
}));

describe("test all routes", () => {
  beforeAll(() => {
    require("../../../main/routes/userRoutes");
  });
  afterEach(() => {
    jest.resetModules();
    jest.restoreAllMocks();
  });

  test("should render Get /users", () => {
    expect(getSpy).toHaveBeenCalledWith("/users", getUsers);
  });

  test("should render Get /user/:id", () => {
    expect(getSpy).toHaveBeenCalledWith("/user/:id", userAuth, getUserById);
  });

  test("should render Post /user", () => {
    expect(postSpy).toHaveBeenCalledWith("/user/new", createUser);
  });

  test("should render Patch /user/:id", () => {
    expect(patchSpy).toHaveBeenCalledWith("/user/update/:id", userAuth, updateUser);
  });

  test("should render Delete /user/:id", () => {
    expect(deleteSpy).toHaveBeenCalledWith("/user/delete/:id", userAuth, deleteUserById);
  });
});
