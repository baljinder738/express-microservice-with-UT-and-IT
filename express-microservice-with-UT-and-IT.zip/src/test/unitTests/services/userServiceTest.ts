"use strict";

import UserServiceImpl from "../../../main/services/userService";
import data from "../../../main/config/data";
import { User } from "../../../main/models/user";
import UserRepositoryImpl from "../../../main/repositories/userRepository";

const mockRepoImpl = jest.fn();
const mockDeleteRepoImpl = jest.fn();
const mockGetUserById = jest.fn();
const mockCreateUser = jest.fn();

jest.mock("../../../main/repositories/userRepository",() => {
  return jest.fn().mockImplementation(() => {
    return { getAllUserData: mockRepoImpl.mockReturnValue(data),
             deleteUserById: mockDeleteRepoImpl.mockImplementation(() => { 
               const userIndex = data.findIndex((user) => user.id === mockDeleteRepoImpl.mock.calls[0][0]);
               const deletedUser = data[userIndex];
               data.splice(userIndex, 1); 
               return deletedUser;
              }),
             getUserById: mockGetUserById.mockImplementation(() => {
              const userById = data.find((user) => user.id === mockGetUserById.mock.calls[0][0])!
              return userById;
             }),
             createUser: mockCreateUser.mockImplementation(() => {
              data.push(mockCreateUser.mock.calls[0][0]);
              return mockCreateUser.mock.calls[0][0]
             }),
            };
  });
})



beforeEach(() => {
// Clear all instances and calls to constructor and all methods:
(UserRepositoryImpl as jest.Mock).mockClear();
mockRepoImpl.mockClear();
mockDeleteRepoImpl.mockClear();
mockCreateUser.mockClear();
 });

 
 test('The service should be able to call new() on UserRepoImpl', () => {
  const userService = new UserServiceImpl();
  // Ensure constructor created the object:
  expect(userService).toBeTruthy();
});

test('We can check if the service called the class constructor', () => {
  const userService = new UserServiceImpl();
  expect(UserRepositoryImpl).toHaveBeenCalledTimes(1);
});

test('We can check if the service.getAllUserData(); called a method on the class instance', () => {
  const service = new UserServiceImpl();
  const res = data;
  service.getAllUserData();
  expect(service.getAllUserData()).toEqual(res)
});

test('We can check if the mocked repo returns the same value. for service.getAllUserData();', () => {
  const service = new UserServiceImpl();
  const res = data;
  service.getAllUserData();     
  expect(service.getAllUserData()).toEqual(res)
  expect(mockRepoImpl.mock.results[0].value).toEqual(res);
});

test('We can check if the service.deleteUserById called a method on the class instance', () => {
  const service = new UserServiceImpl();
  const id: number = 1;
  expect(service.deleteUserById(id)).toEqual({"age": 21, "gender": "Male", "id": 1, "name": "amit"})
});

test('We can check if the mocked repo returns the same value. for service.deleteUserById();', () => {
  const service = new UserServiceImpl();
  const id: number = 10;
  service.deleteUserById(id);
  expect(mockDeleteRepoImpl.mock.calls[0][0]).toEqual(id);
  expect(mockDeleteRepoImpl.mock.results[0].value).toEqual({ id: 10, name: 'swapnil', age: 20, gender: 'Female' });
});

test("We can test if service.deleteUserById throws an error.", async () => {
  const service = new UserServiceImpl();
  const id: number = 30;
  expect(service.deleteUserById(id)).toThrow(new Error("the user is invalid"));​
});

test('We can check if the service.getUserById called a method on the class instance', () => {
  const service = new UserServiceImpl();
  const id: number = 5;
  expect(service.getUserById(id)).toEqual({ id:5, name: "anil", age: 20, gender: "Female" })
});

test('We can check if the mocked repo returns the same value. for service.getUserById();', () => {
  const service = new UserServiceImpl();
  const id: number = 5;
  service.getUserById(id);
  expect(mockGetUserById.mock.calls[0][0]).toEqual(id);
  expect(mockGetUserById.mock.results[0].value).toEqual({ id:5, name: "anil", age: 20, gender: "Female" });
});

test('We can check if the service.createUser called a method on the class instance', () => {
  const service = new UserServiceImpl();
  const user: User = { id:11, name: "anil singh", age: 40, gender: "Male" };
  expect(service.createUser(user)).toEqual({ id:11, name: "anil singh", age: 40, gender: "Male" })
});

test('We can check if the mocked repo returns the same value. for service.createUser', () => {
  const service = new UserServiceImpl();
  const user: User = { id:11, name: "anil singh", age: 40, gender: "Male" };
  service.createUser(user);
  expect(mockCreateUser.mock.calls[0][0]).toEqual(user);
  expect(mockCreateUser.mock.results[0].value).toEqual({ id:11, name: "anil singh", age: 40, gender: "Male" });
});

