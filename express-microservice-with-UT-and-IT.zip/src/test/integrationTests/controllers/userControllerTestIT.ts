"use strict";

import request from 'supertest';
import data from "../../../main/config/data";
import app from '../../../main/index';
import { User } from "../../../main/models/user";

var newData:User[] = [];
describe("testing-server-routes", () => {
beforeEach(() => {
  newData = data;
})
  test("GET /users - success", async () => {
    request(app)
    .get("/users")//uses the request function that calls on express app instance
    .expect(data)
    .expect(200)
    .end(function(err, res){
        expect(res.text).toEqual(JSON.stringify(newData));
    }); 
  });

  test("GET /users/:id - success", () => {
    request(app)
    .get("/user/1")
    .auth("Bearer", "")
    .expect(200, function(err, res) {
      expect(res.text).toEqual(JSON.stringify({"id":1,"name":"amit","age":21,"gender":"Male"}));
    })
  });

  test("GET /users/:id - on not sending bearer token it should failed.", () => {
    request(app)
    .get("/user/1")
    .expect(401, function(err, res) {
      expect(res.unauthorized).toEqual(true);
    })
  });
 
  test("POST /user/new - Push data to api success: 200",   function (done) {
    const userObj = {id:13, name: "lalit121", age: 34, gender: "Male" };
    const newUserObj = {"user": userObj}
     request(app)
    .post("/user/new")
    .send(newUserObj)
    .set("Accept", "application/json")
    .expect('Content-Type', "application/json; charset=utf-8")
    .expect(200)
    .end(function(err, res) {
      // if (err) return done(err);
      // return done();
      // var newObj = newData;
      // newObj.push(userObj)
      console.log("===>",res.text)
      expect(res.text).toEqual(JSON.stringify(userObj))
    })
  });

  test("POST /user/new - Error if api fails: 400",  function (done) {
    const userObj = "hi";
    request(app)
    .post("/user/new")
    .set("Accept", "application/json")
    .expect('Content-Type', "text/html; charset=utf-8")
    .expect(400)
    .end(function(err, res) {
      if (err) return done(err);
      return done();
    })
  });

});