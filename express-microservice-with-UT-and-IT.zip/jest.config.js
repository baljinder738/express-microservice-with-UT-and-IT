const {defaults} = require('jest-config');

module.exports = {
    verbose: true,
    preset: 'ts-jest',
    testResultsProcessor: "./node_modules/jest-html-reporter",
    testEnvironment: 'node',
    //rootDir: "./src/test/",
    testMatch: ['**/__tests__/**/*.+(ts|tsx|js)', '**/?(*.)+(ts|tsx|js)'],
    transform: {
      '^.+\\.(ts|tsx)?$': 'ts-jest',
    },
    // transformIgnorePatterns: [
    //   "node_modules", "output"
    // ],
  };