/* eslint-disable linebreak-style */
/* eslint-disable no-var */
/* eslint-disable linebreak-style */
var gulp = require("gulp");

var ts = require("gulp-typescript");

var tsProject = ts.createProject("tsconfig.json");

gulp.task("default", () => tsProject.src().pipe(tsProject()).js.pipe(gulp.dest("dist")));
