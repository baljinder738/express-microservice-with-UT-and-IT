const config = require('./jest.config')
config.testMatch = ['**/__tests__/**/*.+(ts|tsx|js)', '**/?(*.)+(ts|tsx|js)']
module.exports = config